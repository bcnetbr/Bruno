package modelos;

public class Venda {

    int codigo;
    int tipo;
    Cliente cliente;
    Vendedor vendedor;
    Carro carro;
    double valor;

    public Venda(int codigo, int tipo, Cliente cliente, Vendedor vendedor, Carro carro, double valor) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.carro = carro;
        this.valor = valor;
    }

}
