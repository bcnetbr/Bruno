package modelos;

public class Cliente {

    int codigo;
    String nome;
    String cpf;
    String telefone;
    String endereco;

    public Cliente(int codigo, String nome, String cpf, String telefone, String endereco) {
        this.codigo = codigo;
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.endereco = endereco;
    }

    public void comprar(Carro carro) {
        System.out.println("Iniciando pedido de venda..............");
        System.out.println("O cliente " + this.nome + " quer comprar o carro " + carro.modelo + ".");
        System.out.println("-----------------------------------------------------------");
    }

    public void fazerTestDrive(Carro carro, String opiniao) {
        System.out.println("------- Parecer do teste drive do " + carro.modelo + " -------");
        System.out.println("Eu " + this.nome + " " + opiniao + " do carro " + carro.modelo);
        System.out.println("-----------------------------------------------------------");
    }

}
