package modelos;

public class Carro {
    
    public static String companhia = "Revendedora SENAC";
    public String placa;
    public String modelo;
    public String marca;
    public double preco;
    public int ano;

    public Carro() {
    }

    public Carro(String placa, String modelo, String marca, double preco, int ano) {
        this.placa = placa;
        this.modelo = modelo;
        this.marca = marca;
        this.preco = preco;
        this.ano = ano;
    }

}
