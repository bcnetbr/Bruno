package revendedora;
import modelos.Carro;
import modelos.Vendedor;
import modelos.Cliente;

public class Revendedora {

    public static void main(String[] args) {
        /*
        Instanciando objetos das classes declaradas
        */
        //enviando parametros via construtor
        Vendedor vendedor1 = new Vendedor("1333", "Alberto");
        Vendedor vendedor2 = new Vendedor("2783", "João", 2000.00);
        Cliente cliente1 = new Cliente(167, "Douglas", "0281323453", "111-111", "");
        
        
        //acessando atributos publicos diretamente
        Carro celta = new Carro();
        celta.ano = 2017;
        celta.modelo = "Celta";
        celta.marca ="Wolkswagen";
        celta.placa = "XRD2000";
        celta.preco = 38000;
        
        //enviando parametros via construtor
        Carro gol = new Carro("XHA3344", "Gol", "Wolkswagen", 45000, 2019);
        
        /*
        fim da instaciacao de objetos
        */
        
        //Imprimindo vendedores disponíveis
        System.out.println("---------Vendedores Disponíveis----------");
        System.out.println("Nome vendedor 1: " + vendedor1.nome);
        System.out.println("Nome vendedor 2: " + vendedor2.nome);
        System.out.println("-----------------------------------------");
        
        //Imprimindo carros disponíveis
        System.out.println("---------Carros disponíveis----------");
        System.out.println("Nome da revendedora: " + celta.companhia);//atributo de classe
        System.out.println("Modelo do carro: " + celta.modelo);
        System.out.println("Marca da carro: " + celta.marca);
        System.out.println("");
        System.out.println("Nome da revendedora: " + gol.companhia);
        System.out.println("Modelo do carro: " + gol.modelo);
        System.out.println("Marca da carro: " + gol.marca);
        System.out.println("--------------------------------------------");
        
        
        //Enviando mensagem atraves do objeto da classe Cliente
        cliente1.fazerTestDrive(celta, "não gostei");
        cliente1.fazerTestDrive(gol, "gostei");
        
        //Enviando mensagem atraves do objeto da classe Cliente
        cliente1.comprar(gol);
        //Enviando mensagem atraves do objeto da classe Vendedor
        vendedor1.vender(123, 2, cliente1, vendedor1, gol, 40000);
        
    }
    
}
