package modelos;

public class Vendedor {

    public String matricula;
    public String nome;
    public double salario;
    public int quantidadeVendas;

    public Vendedor(String matricula, String nome) {
        this.matricula = matricula;
        this.nome = nome;
    }

    public Vendedor(String matricula, String nome, double salario) {
        this.matricula = matricula;
        this.nome = nome;
        this.salario = salario;
    }

    public Cliente fazerCadastro(Cliente cliente) {
        return cliente;
    }

    public Venda vender(int codigoVenda, int tipoVenda, Cliente cliente, Vendedor vendedor, Carro carro, double valor) {
        Venda venda = new Venda(codigoVenda, tipoVenda, cliente, vendedor, carro, valor);
        System.out.println("------- O vendedor " + vendedor.nome + " iniciou o registro da venda -------");
        this.registrarVenda(venda);//chamando outro metodo dentro da propria classe
        System.out.println("--------------------------------------------------------------------");
        return venda;
    }

    public void registrarVenda(Venda venda) {
        System.out.println("Venda " + venda.codigo + " para cliente " + venda.cliente.nome + "foi realizada com sucesso.");
    }
}
